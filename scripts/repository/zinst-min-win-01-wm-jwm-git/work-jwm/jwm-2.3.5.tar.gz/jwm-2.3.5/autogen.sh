#!/bin/sh
automake -a
autoreconf --install --force
